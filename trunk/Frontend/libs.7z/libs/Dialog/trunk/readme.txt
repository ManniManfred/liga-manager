Dialog contrib
==============

The Dialog project provides many often-used widgets required in user
interaction, such as alert, confirm, prompt, and others that simplify
the web developer's daily work. 